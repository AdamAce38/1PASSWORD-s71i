---
editor_options: 
  markdown: 
    wrap: 72
---

# ZIProp 0.1.1  

- Add vignette 
- Add NEWS.md file
- Add two dataset *diffFactors.rda* and *equineDiffFactors.rda*
