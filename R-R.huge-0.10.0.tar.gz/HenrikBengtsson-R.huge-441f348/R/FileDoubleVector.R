setConstructorS3("FileDoubleVector", function(...) {
  extend(FileVector(..., bytesPerCell=8, storageMode="double"), "FileDoubleVector")
})


############################################################################
# HISTORY:
# 2006-01-27
# o Created.
############################################################################ 
