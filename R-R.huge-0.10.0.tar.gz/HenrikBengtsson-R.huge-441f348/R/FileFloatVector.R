setConstructorS3("FileFloatVector", function(...) {
  extend(FileVector(..., bytesPerCell=4, storageMode="double"), "FileFloatVector")
})


############################################################################
# HISTORY:
# 2006-02-27
# o Created.
############################################################################ 
