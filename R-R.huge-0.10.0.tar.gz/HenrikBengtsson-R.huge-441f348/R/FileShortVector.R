setConstructorS3("FileShortVector", function(...) {
  extend(FileVector(..., bytesPerCell=2, storageMode="integer"), "FileShortVector")
})


############################################################################
# HISTORY:
# 2006-01-27
# o Created.
############################################################################ 
