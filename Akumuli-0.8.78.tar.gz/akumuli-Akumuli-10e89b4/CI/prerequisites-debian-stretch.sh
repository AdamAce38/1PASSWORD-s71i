#!/bin/sh

apt-get update
apt-get install -y build-essential
apt-get install -y libboost-all-dev
apt-get install -y libapr1-dev libaprutil1-dev libaprutil1-dbd-sqlite3
apt-get install -y liblog4cxx10-dev liblog4cxx10v5
apt-get install -y libjemalloc-dev
apt-get install -y libsqlite3-dev
apt-get install -y libmicrohttpd-dev
apt-get install -y libmuparser-dev
apt-get install -y cmake
