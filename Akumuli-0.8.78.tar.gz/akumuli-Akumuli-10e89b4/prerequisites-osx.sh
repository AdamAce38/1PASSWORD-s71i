brew install cmake
brew install boost
brew install log4cxx
brew install jemalloc
brew install sqlite
brew install libmicrohttpd
brew install apr
brew install apr-util
