# 2nd part of is-dbg-ok. 
:
exit 0
