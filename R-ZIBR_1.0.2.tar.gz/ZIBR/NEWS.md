# ZIBR 1.0.2

* Fix license file inclusion

# ZIBR 1.0.0

* Fix redirect links

# ZIBR 0.1

* Initial CRAN submission.
