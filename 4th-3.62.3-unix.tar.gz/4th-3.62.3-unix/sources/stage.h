static unit EmbeddedHX [] = { '\x00' };
