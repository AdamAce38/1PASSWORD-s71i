# QuickJSR

<!-- badges: start -->
[![R-CMD-check](https://github.com/andrjohns/QuickJSR/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/andrjohns/QuickJSR/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->

R interface for the QuickJS lightweight javascript engine
