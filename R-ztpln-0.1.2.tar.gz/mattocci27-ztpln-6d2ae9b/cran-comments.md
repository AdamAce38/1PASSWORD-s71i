This is a patch release that fixes unbalanced code chunk delimiters in vignettes.
It has no user facing changes.

# Test environments

* ubuntu 20.4, r-devel, r-release, r-oldrel, GCC (Github Actions)
* macOS 10.16, Apple Silicon (M1), r-release, clang (local)
* Windows Server 2019, r-devel, r-release, r-oldrel, 32/64 bit (Github Actions)
* Oracle Solaris 10, x86, 32 bit, R-release (Rhub)
