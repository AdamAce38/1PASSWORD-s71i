library(testthat)
library(ztpln)

test_check("ztpln")
