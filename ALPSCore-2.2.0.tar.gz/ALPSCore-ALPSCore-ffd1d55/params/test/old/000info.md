Files in this directory are unit tests for the old
(boost::program_options based) implementation of parameters.
They will be gradually moved to the new unit tests set or removed.
