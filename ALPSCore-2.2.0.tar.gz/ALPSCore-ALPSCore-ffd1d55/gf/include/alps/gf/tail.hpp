/*
 * Copyright (C) 1998-2018 ALPS Collaboration. See COPYRIGHT.TXT
 * All rights reserved. Use is subject to license terms. See LICENSE.TXT
 * For use in publications, see ACKNOWLEDGE.TXT
 */

#ifndef ALPSCORE_GF_TAIL_H
#define ALPSCORE_GF_TAIL_H

#include <alps/gf/gf.hpp>

#endif //ALPSCORE_GF_TAIL_H
