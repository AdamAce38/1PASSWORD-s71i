This "iniparser" library by Nicolas Devillard
is downloaded from https://github.com/ndevilla/iniparser .
Please see README_orig.md for relevant documentation.
