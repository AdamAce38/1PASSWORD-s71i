## revdepcheck results

We checked 7602 reverse dependencies, comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 6 new problems - I reviewed these and I'm reasonable certain that
   they're stochastic failures unrelated to testthat.
   
 * We failed to check 13 packages

Issues with CRAN packages are summarised below.

### New problems

* appler
* batata
* bayes4psy
* covidcast
* paws.common
* xpose

### Failed to check

* Boom         (NA)
* CausalImpact (NA)
* ctsem        (NA)
* fdaPDE       (NA)
* gllvm        (NA)
* loon.ggplot  (NA)
* loon.shiny   (NA)
* loon.tourr   (NA)
* Platypus     (NA)
* rstanarm     (NA)
* tidyfit      (NA)
* vivid        (NA)
* xtensor      (NA)
