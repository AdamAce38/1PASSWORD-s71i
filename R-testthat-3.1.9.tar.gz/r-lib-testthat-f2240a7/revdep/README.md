# Revdeps

## New problems (3)

|package   |version |error  |warning |note |
|:---------|:-------|:------|:-------|:----|
|[bayes4psy](problems.md#bayes4psy)|1.2.11  |__+1__ |        |2    |
|[covidcast](problems.md#covidcast)|0.5.0   |__+1__ |        |1    |
|[xpose](problems.md#xpose)|0.4.16  |__+1__ |        |     |

