## revdepcheck results

We checked 218 reverse dependencies, comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 0 new problems
 * We failed to check 2 packages

Issues with CRAN packages are summarised below.

### Failed to check

* loon.shiny (NA)
* loon.tourr (NA)
