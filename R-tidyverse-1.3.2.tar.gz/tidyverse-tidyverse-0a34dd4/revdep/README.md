# Revdeps

## Failed to check (2)

|package    |version |error |warning |note |
|:----------|:-------|:-----|:-------|:----|
|loon.shiny |?       |      |        |     |
|loon.tourr |?       |      |        |     |

