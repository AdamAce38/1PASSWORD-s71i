//
//  main.m
//  AppHack
//
//  Created by Sveinbjorn Thordarson on 11/17/04.
//  Copyright __MyCompanyName__ 2004. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
