bayesx.construct.gs.smooth.spec <- bayesx.construct.geospline.smooth.spec <- function(object, dir, prg, data)
{
  return(geo.smooth.spec(object, dir, prg, data, "geospline"))
}

