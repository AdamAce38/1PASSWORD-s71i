bayesx.construct.bl.smooth.spec <- bayesx.construct.baseline.smooth.spec <- function(object, dir, prg, data) 
{
  return(construct.shrw(object, dir, prg, data, "baseline"))
}

