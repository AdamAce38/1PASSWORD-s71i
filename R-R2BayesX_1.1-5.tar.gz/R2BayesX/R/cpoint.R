cpoint <-
function(a, b) 
{
  return(.Call("cpoint", a, b))
}

