GCV <- function(object, ...)
{
  UseMethod("GCV")
}

