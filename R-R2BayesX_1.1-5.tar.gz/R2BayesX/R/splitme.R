splitme <- function(x)
{
  return(strsplit(x, "")[[1L]])
}

