resplit <- function(x)
{
  if(!is.null(x))
    x <- paste(x, sep = "", collapse = "")
	
  return(x)
}

