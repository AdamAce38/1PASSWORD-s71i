bayesx.construct.rw2.smooth.spec <- function(object, dir, prg, data) 
{
  return(construct.shrw(object, dir, prg, data, "rw2"))
}

