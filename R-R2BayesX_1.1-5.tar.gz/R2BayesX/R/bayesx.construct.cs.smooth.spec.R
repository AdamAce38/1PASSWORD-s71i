bayesx.construct.cs.smooth.spec <- bayesx.construct.catspecific.smooth.spec <- function(object, dir, prg, data) 
{
  return(construct.shrw(object, dir, prg, data, "catspecific"))
}

