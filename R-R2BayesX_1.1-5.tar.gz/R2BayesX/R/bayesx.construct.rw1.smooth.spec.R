bayesx.construct.rw1.smooth.spec <- function(object, dir, prg, data) 
{
  return(construct.shrw(object, dir, prg, data, "rw1"))
}

