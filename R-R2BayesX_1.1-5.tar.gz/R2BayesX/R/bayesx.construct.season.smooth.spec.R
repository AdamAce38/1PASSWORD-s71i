bayesx.construct.season.smooth.spec <- function(object, dir, prg, data) 
{
  return(construct.shrw(object, dir, prg, data, "season"))
}

