DIC <- function(object, ...)
{
  UseMethod("DIC")
}

