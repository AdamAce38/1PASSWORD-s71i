bayesx.construct.nigmix.smooth.spec <- function(object, dir, prg, data) 
{
  return(construct.shrw(object, dir, prg, data, "nigmix"))
}

