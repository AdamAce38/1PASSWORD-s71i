What's here:

* unit:  unit tests
* integration: integration tests
* examples: scripts used by integration tests
* data: debugger command files and output for comparision in integration tests
