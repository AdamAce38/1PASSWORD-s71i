#!/usr/bin/env zsh
x=1
echo "file with spaces here"
