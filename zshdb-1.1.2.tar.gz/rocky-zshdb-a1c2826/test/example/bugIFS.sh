#!/bin/zsh
IFS="."
PS4='foo'
exit 0
