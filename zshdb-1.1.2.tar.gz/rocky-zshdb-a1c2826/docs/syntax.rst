Command Syntax
**************

.. toctree::
   :maxdepth: 1

   syntax/command
   syntax/suffixes
