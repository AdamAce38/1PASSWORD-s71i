.. index:: unalias
.. _unalias:

Unalias (remove debugger command alias)
---------------------------------------

**unalias** *alias-name*

Remove alias *alias-name*.

.. seealso::

   :ref:`alias <alias>`.
