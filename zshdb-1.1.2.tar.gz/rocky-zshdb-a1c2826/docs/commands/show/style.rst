.. index:: show; style
.. _show_style:

Show Style (pygments formatting style)
--------------------------------------
**show style** *pygments-style*

Show the pygments style used in formatting 256-color terminal text.

.. seealso::

   :ref:`set style <set_style>` and :ref:`show highlight <show_highlight>`
