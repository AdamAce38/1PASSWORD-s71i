.. index:: show; trace-commands
.. _show_trace-commands:

Show trace command (show debugger commands before running)
----------------------------------------------------------

**show trace-commands**

Show tracking commands before running them

.. seealso::

   :ref:`set trace-commands <set_trace-commands>`
