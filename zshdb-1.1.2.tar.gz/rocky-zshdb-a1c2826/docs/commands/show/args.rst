.. index:: show; args
.. _show_args:

Show Args (arguments when program is started)
---------------------------------------------

**show args**

Show the argument list to give debugged program when it is started
