.. index:: show; highlight
.. _show_highlight:

Show Highlight (terminal highlighting)
--------------------------------------

**show highlight**

Show whether we use terminal highlighting.

.. seealso::

   :ref:`set highlight <set_highlight>`
