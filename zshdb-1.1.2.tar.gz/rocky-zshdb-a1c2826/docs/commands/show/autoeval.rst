.. index:: show; autoeval
.. _show_autoeval:

Show Autoeval (auto evaluation of unrecognized debugger commands)
-----------------------------------------------------------------

**show autoeval**

Show whether zsh evaluate of unrecognized debugger commands.

.. seealso::

   :ref:`set autoeval <set_autoeval>`
