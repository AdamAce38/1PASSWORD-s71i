.. index:: show; width
.. _show_width:

Show Width (terminal width)
---------------------------

**show width**

Show the number of characters the debugger thinks are in a line.

.. seealso::

   :ref:`set width <set_width>`
