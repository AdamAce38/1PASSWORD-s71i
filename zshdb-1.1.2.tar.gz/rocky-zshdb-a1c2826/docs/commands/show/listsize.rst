.. index:: show; listsize
.. _show_listsize:

Show Listsize (list command line count)
---------------------------------------

**show listsize**

Show the number lines printed in a :ref:`list <list>` command by default

.. seealso::

   :ref:`set listsize <set_listsize>`
