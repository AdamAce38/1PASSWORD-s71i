.. index:: show; editing
.. _show_editing:

Show Editing (readline editing)
-------------------------------

**show editing**

Show editing of command lines as they are typed.

.. seealso::

   :ref:`set editing <set_editing>`
