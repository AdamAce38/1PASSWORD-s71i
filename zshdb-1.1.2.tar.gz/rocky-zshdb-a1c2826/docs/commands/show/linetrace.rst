.. index:: show; linetrace
.. _show_linetrace:

Show Linetrace (whether each sourceline is traced before running it)
---------------------------------------------------------------------

**show linetrace**

Show whether each sourceline is traced before running it.

.. seealso::

   :ref:`set linetrace <set_linetrace>`
