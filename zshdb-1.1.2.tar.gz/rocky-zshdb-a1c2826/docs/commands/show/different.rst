.. index:: show; different
.. _show_different:

Show Different (consecutive stops on different file/line positions)
-------------------------------------------------------------------

Show consecutive stops on different file/line positions

.. seealso::

   :ref:`set different <set_different>`
