.. index:: show; confirm
.. _show_confirm:

Show Confirm (confirmation of potentially dangerous operations)
--------------------------------------------------------------------

**show confirm**

Show confirmation of potentially dangerous operations

.. seealso::

   :ref:`show confirm <show_confirm>`
