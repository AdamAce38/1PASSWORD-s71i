.. index:: show; autolist
.. _show_autolist:

Show Autolist
-------------

**show autolist**

Run a debugger ref:`list <list>` command automatically on debugger entry.

.. seealso::

   :ref:`set autolist <set_autolist>`
