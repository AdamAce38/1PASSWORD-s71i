.. index:: show; basename
.. _show_basename:

Show Basename (basename only in file path)
------------------------------------------

**show basename**

Show whether filename basenames or full path names are shown.

.. seealso::

   :ref:`set basename <set_basename>`
