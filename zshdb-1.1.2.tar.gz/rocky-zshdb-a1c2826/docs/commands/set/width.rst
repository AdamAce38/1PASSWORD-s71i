.. index:: set; width
.. _set_width:

Set Width (terminal width)
--------------------------

**set width** *number*

Set the number of characters the debugger thinks are in a line.

.. seealso::

   :ref:`show width <show_width>`
