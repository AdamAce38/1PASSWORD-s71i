.. index:: set; trace-commands
.. _set_trace-commands:

Set trace commands (show debugger commands before running)
----------------------------------------------------------

**set trace-commands** [ **on** | **off** ]

Set echoing lines read from debugger command files

.. seealso::

   :ref:`show trace-commands <show_trace-commands>`
