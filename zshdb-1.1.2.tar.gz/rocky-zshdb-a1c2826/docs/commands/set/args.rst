.. index:: set; args
.. _set_args:

Set Args (progam arguments)
-------------------------------

**set args** [*script-args*]

Set argument list to give program being debugged when it is started.
Follow this command with any number of args, to be passed to the program.

.. seealso::

   :ref:`run <run>`
