.. index:: set; editing
.. _set_editing:

Set Editing (readline editing of commands)
------------------------------------------

**set editing** [ **on** | **off** | **emacs** | **vi** ]

Readline editing of command lines.

.. seealso::

   :ref:`show editing <show_editing>`
