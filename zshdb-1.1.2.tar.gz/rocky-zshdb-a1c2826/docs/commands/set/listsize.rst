.. index:: set; listsize
.. _set_listsize:

Set Listsize (list command line count)
--------------------------------------

**set listsize** *number-of-lines*

Set the number lines printed in a :ref:`list <list>` command by default

.. seealso::

   :ref:`show listsize <show_listsize>`
