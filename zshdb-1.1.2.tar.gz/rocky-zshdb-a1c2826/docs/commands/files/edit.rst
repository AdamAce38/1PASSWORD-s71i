.. index:: edit
.. _edit:

Edit
----

**edit** *position*

Edit specified file or module.
With no argument, edits file containing most recent line listed.

.. seealso::

   :ref:`list <list>`
