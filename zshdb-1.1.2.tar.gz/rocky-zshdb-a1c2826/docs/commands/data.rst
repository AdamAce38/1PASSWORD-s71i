Data
====

Examining data.

.. toctree::
   :maxdepth: 1

   data/display
   data/eval
   data/examine
   data/load
   data/undisplay
