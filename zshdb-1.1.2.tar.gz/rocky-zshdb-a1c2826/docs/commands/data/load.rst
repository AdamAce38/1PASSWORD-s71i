.. index:: load
.. _load:

Load (source zsh file)
-------------------------

**load** *zsh-script*

Read in lines of a *zsh-script*.

.. seealso::

   :ref:`info files <info_files>`.
