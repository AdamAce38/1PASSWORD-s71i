.. index:: disable
.. _disable:

Disable (disable breakpoints)
-----------------------------

**disable** *bpnumber* [*bpnumber* ...]

Disables the breakpoints given as a space separated list of breakpoint
numbers. See also `info break` to get a list.

.. seealso::

   :ref:`enable <enable>`
