.. index:: delete
.. _delete:

Delete (remove breakpoints)
---------------------------

**delete** [*bpnumber* [*bpnumber*...]]

Delete some breakpoints.

Arguments are breakpoint numbers with spaces in between.  To delete
all breakpoints, give no argument.  Without
arguments, clear all breaks (but first ask confirmation).

.. seealso::

   :ref:`clear <clear>`
