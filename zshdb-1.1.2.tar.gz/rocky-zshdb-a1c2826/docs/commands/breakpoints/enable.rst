.. index:: enable
.. _enable:

Enable (enable breakpoints)
---------------------------

**enable** *bpnumber* [*bpnumber* ...]

Enables the breakpoints given as a space separated list of breakpoint
numbers. See also `info break` to get a list.

.. seealso::

   :ref:`disable <disable>`, :ref:`tbreak <tbreak>`
