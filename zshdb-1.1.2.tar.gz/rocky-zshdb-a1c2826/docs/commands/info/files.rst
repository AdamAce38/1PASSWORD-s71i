.. index:: info; files
.. _info_files:

Info Files
------------

**info files**

Show a list of files that have been read in and properties regarding them.

.. seealso::

   :ref:`load`
