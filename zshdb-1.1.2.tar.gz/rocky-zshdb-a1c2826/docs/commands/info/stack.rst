.. index:: info; stack
.. _info_stack:

Info Stack
-----------

**info stack**

An alias for **backtrace**

.. seealso::

   :ref:`backtrace <backtrace>`
