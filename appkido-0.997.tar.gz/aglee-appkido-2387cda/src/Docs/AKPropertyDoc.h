//
//  AKPropertyDoc.h
//  AppKiDo
//
//  Created by Andy Lee on 7/25/08.
//  Copyright 2008 Andy Lee. All rights reserved.
//

#import "AKMemberDoc.h"

@interface AKPropertyDoc : AKMemberDoc
@end
