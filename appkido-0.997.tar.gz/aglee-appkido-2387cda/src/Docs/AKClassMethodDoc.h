/*
 * AKClassMethodDoc.h
 *
 * Created by Andy Lee on Sun Mar 21 2004.
 * Copyright (c) 2003, 2004 Andy Lee. All rights reserved.
 */

#import "AKMemberDoc.h"

@interface AKClassMethodDoc : AKMemberDoc
@end
