Got these classes from Gus Mueller's web site:

http://www.gusmueller.com/blog/archives/2005/3/22.html

Added /usr/lib/libsqlite3.dylib to "Other Frameworks".

