//
//  AKServicesProvider.h
//  AppKiDo
//
//  Created by Andy Lee on 7/16/12.
//  Copyright (c) 2012 Andy Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AKServicesProvider : NSObject
@end
