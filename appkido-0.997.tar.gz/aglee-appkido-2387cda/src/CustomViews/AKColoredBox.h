/*
 * AKColoredBox.h
 *
 * Created by Andy Lee on Fri Jul 04 2003.
 * Copyright (c) 2003, 2004 Andy Lee. All rights reserved.
 */

#import <AppKit/AppKit.h>

@interface AKColoredBox : NSBox
@end
