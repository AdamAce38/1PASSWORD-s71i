/*
 * AKApplication.h
 *
 * Created by Andy Lee on Thu Mar 18 2007.
 * Copyright (c) 2003-2007 Andy Lee. All rights reserved.
 */

#import <Cocoa/Cocoa.h>

@interface AKApplication : NSApplication
@end
