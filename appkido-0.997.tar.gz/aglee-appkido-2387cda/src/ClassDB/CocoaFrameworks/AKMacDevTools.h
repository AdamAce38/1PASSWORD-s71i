//
//  AKMacDevTools.h
//  AppKiDo
//
//  Created by Andy Lee on 2/11/09.
//  Copyright 2009 Andy Lee. All rights reserved.
//

#import "AKDevTools.h"

@interface AKMacDevTools : AKDevTools
@end
