//
// AKCategoryNode.h
//
// Created by Andy Lee on Wed Jun 26 2002.
// Copyright (c) 2003, 2004 Andy Lee. All rights reserved.
//

#import "AKBehaviorNode.h"

/*!
 * Represents an Objective-C category. This class currently isn't complete and
 * isn't used for anything serious.
 */
@interface AKCategoryNode : AKBehaviorNode
@end
