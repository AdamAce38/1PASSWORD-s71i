//
//  AKPropertyNode.h
//  AppKiDo
//
//  Created by Andy Lee on 7/24/08.
//  Copyright 2008 Andy Lee. All rights reserved.
//

#import "AKMemberNode.h"

@interface AKPropertyNode : AKMemberNode
@end
