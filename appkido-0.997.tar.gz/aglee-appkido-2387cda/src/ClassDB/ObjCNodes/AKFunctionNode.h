//
//  AKFunctionNode.h
//  AppKiDo
//
//  Created by Andy Lee on 4/25/08.
//  Copyright 2008 Andy Lee. All rights reserved.
//

#import "AKDatabaseNode.h"

/*!
 * Represents a C function.
 */
@interface AKFunctionNode : AKDatabaseNode
@end
