/*
 * AKCocoaFunctionsDocParser.h
 *
 * Created by Andy Lee on Sun Mar 28 2004.
 * Copyright (c) 2003, 2004 Andy Lee. All rights reserved.
 */

#import "AKDocParser.h"

/*
 * Parses an HTML file that documents a framework's functions.
 */
@interface AKCocoaFunctionsDocParser : AKDocParser
@end
