//
//  AKGlobalsGroupSubtopic.h
//  AppKiDo
//
//  Created by Andy Lee on 4/4/13.
//  Copyright (c) 2013 Andy Lee. All rights reserved.
//

#import "AKGroupNodeSubtopic.h"

@interface AKGlobalsGroupSubtopic : AKGroupNodeSubtopic
@end
