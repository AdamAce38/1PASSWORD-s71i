/*
 * AKFunctionsGroupSubtopic.h
 *
 * Created by Andy Lee on Sun May 30 2004.
 * Copyright (c) 2004 Andy Lee. All rights reserved.
 */

#import "AKGroupNodeSubtopic.h"

@interface AKFunctionsGroupSubtopic : AKGroupNodeSubtopic
@end
