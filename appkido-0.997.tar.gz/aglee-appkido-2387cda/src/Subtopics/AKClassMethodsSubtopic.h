/*
 * AKClassMethodsSubtopic.h
 *
 * Created by Andy Lee on Wed Jul 03 2002.
 * Copyright (c) 2003, 2004 Andy Lee. All rights reserved.
 */

#import "AKRealMethodsSubtopic.h"

@interface AKClassMethodsSubtopic : AKRealMethodsSubtopic
@end

