# AlphaHull3D 2.0.0

Full alpha hull.


# AlphaHull3D 1.1.0

* Enabled C++ 17.

* In the previous version, the volume of the alpha hull actually was the volume 
of the convex hull. Now the volume option returns the volume of the exterior 
cells and the volume of the interior cells.


# AlphaHull3D 1.0.0

First release.
