#' @title Great stellated dodecahedron
#'
#' @description The vertices of the great stellated dodecahedron (Bowers 
#'   acronym: gissid).
#'
#' @format A numeric matrix with 32 rows.
"gissid"
