# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# Make functions callable from the command line
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
rcat <- CmdArgsFunction(rcat)
rclean <- CmdArgsFunction(rclean)
rcode <- CmdArgsFunction(rcode)
rcompile <- CmdArgsFunction(rcompile)
rfile <- CmdArgsFunction(rfile)
rsource <- CmdArgsFunction(rsource)
rstring <- CmdArgsFunction(rstring)
