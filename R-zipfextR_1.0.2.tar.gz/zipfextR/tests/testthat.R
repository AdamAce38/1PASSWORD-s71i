library(testthat)
library(zipfextR)

test_check("zipfextR")
