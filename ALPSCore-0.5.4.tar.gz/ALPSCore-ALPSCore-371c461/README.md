The ALPSCore project, based on the ALPS (Algorithms and Libraries for Physics Simulations) project, provides generic algorithms and utilities for physics problems. It strives to increase software reuse in the physics community.

For copyright see COPYRIGHT.txt
For licensing see LICENSE.txt
For acknowledgment in scientific publications see ACKNOWLEDGE.txt
