## revdepcheck results

We checked 9101 reverse dependencies (7910 from CRAN + 1191 from Bioconductor), comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 1 new problems
 * We failed to check 11 packages

Issues with CRAN packages are summarised below.

### New problems
(This reports the first line of each new failure)

* miWQS
  checking re-building of vignette outputs ... ERROR

### Failed to check

* bayesdfa         (NA)
* Boom             (NA)
* ctsem            (NA)
* fdaPDE           (NA)
* gllvm            (NA)
* glmmrOptim       (NA)
* loon.shiny       (NA)
* loon.tourr       (NA)
* rstanarm         (NA)
* TriDimRegression (NA)
* triptych         (NA)
