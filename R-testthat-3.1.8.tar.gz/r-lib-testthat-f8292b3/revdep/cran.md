## revdepcheck results

We checked 7489 reverse dependencies, comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 8 new problems
 * We failed to check 9 packages

Issues with CRAN packages are summarised below.

### New problems
(This reports the first line of each new failure)

* bookdown
  checking tests ... ERROR

* crosstable
  checking tests ... ERROR

* curl
  checking re-building of vignette outputs ... ERROR

* extras
  checking tests ... ERROR

* morpheus
  checking tests ... ERROR

* PKNCA
  checking tests ... ERROR

* rlang
  checking tests ... ERROR

* tinytiger
  checking tests ... ERROR

### Failed to check

* Boom        (NA)
* ctsem       (NA)
* fdaPDE      (NA)
* gllvm       (NA)
* loon.ggplot (NA)
* loon.shiny  (NA)
* loon.tourr  (NA)
* vivid       (NA)
* xtensor     (NA)
