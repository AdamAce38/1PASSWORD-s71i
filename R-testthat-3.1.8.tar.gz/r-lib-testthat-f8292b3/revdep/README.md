# Revdeps

## Failed to check (9)

|package     |version  |error |warning |note |
|:-----------|:--------|:-----|:-------|:----|
|Boom        |0.9.11   |1     |        |     |
|ctsem       |3.7.6    |1     |        |     |
|fdaPDE      |1.1-16   |1     |        |     |
|gllvm       |1.4.1    |1     |        |     |
|loon.ggplot |?        |      |        |     |
|loon.shiny  |?        |      |        |     |
|loon.tourr  |?        |      |        |     |
|vivid       |?        |      |        |     |
|xtensor     |0.14.1-0 |1     |        |     |

## New problems (8)

|package    |version |error     |warning |note |
|:----------|:-------|:---------|:-------|:----|
|[bookdown](problems.md#bookdown)|0.33    |__+1__    |        |     |
|[crosstable](problems.md#crosstable)|0.6.1   |__+1__    |        |     |
|[curl](problems.md#curl)|5.0.0   |-1 __+1__ |        |1    |
|[extras](problems.md#extras)|0.5.0   |__+1__    |        |     |
|[morpheus](problems.md#morpheus)|1.0-4   |__+1__    |        |     |
|[PKNCA](problems.md#pknca)|0.10.1  |__+1__    |        |     |
|[rlang](problems.md#rlang)|1.1.0   |__+1__    |        |1    |
|[tinytiger](problems.md#tinytiger)|0.0.4   |__+1__    |        |     |

