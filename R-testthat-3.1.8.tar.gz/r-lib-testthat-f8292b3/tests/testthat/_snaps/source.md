# source_file wraps error

    Code
      source_file(test_path("reporters/error-setup.R"), wrap = FALSE)
    Condition
      Error in `source_file()`:
      ! In path: "reporters/error-setup.R"
      Caused by error in `h()`:
      ! !

