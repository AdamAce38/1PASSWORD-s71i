## R CMD check results

There were no ERRORs, WARNINGs, or NOTEs.

We checked 7489 reverse dependencies, comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 8 new problems. We sent patches to all affect packages 2 weeks ago:
   https://github.com/r-lib/testthat/issues/1775
 * We failed to check 9 packages

### Failed to check

* Boom        (NA)
* ctsem       (NA)
* fdaPDE      (NA)
* gllvm       (NA)
* loon.ggplot (NA)
* loon.shiny  (NA)
* loon.tourr  (NA)
* vivid       (NA)
* xtensor     (NA)
