###########################################################################/**
# @RdocDocumentation "Deprecated and defunct objects"
#
# \description{
#  The following objects are \emph{defunct}:
#  \itemize{
#   \item None
#  }
#
#  The following objects are \emph{deprecated}:
#  \itemize{
#   \item None
#  }
# }
#
# @keyword internal
#*/###########################################################################

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# DEFUNCT
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# DEPRECATED
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
