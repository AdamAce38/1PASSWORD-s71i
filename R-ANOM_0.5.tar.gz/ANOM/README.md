ANOM
====

R code creating analysis-of-mean decision charts.
