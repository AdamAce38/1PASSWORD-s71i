library(testthat)
library(R2jags)

test_check("R2jags")
