#!/bin/zsh
# For testing break, delete, step, step+ step-, default step and set force.
for ((i=0; i<3; i++)) do print 1st loop $i ; done
for ((i=0; i<3; i++)) do print 2nd loop $i ; done
for ((i=0; i<3; i++)) do print 3rd loop $i ; done
for ((i=0; i<3; i++)) do print 4th loop $i ; done
for ((i=0; i<3; i++)) do print 5th loop $i ; done
for ((i=0; i<3; i++)) do print 6th loop $i ; done
