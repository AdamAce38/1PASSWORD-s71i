#! /bin/bash
echo line 2
echo line 3
echo line 4
echo line 5
echo line 6
echo line 7
echo line 8
