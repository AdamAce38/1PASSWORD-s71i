# provide useful feedback on failure

    1 (`actual`) not identical to "a" (`expected`).
    
    `actual` is [32ma double vector[39m (1)
    `expected` is [32ma character vector[39m ('a')

---

    1 (`actual`) not equal to "a" (`expected`).
    
    `actual` is [32ma double vector[39m (1)
    `expected` is [32ma character vector[39m ('a')

---

    1 not identical to "a".
    Types not compatible: double is not character

---

    1 not equal to "a".
    Types not compatible: double is not character

