#!/bin/sh

sudo apt-get update
sudo apt-get install -y sudo
sudo apt-get install -y libboost-all-dev
sudo apt-get install -y libapr1-dev libaprutil1-dev libaprutil1-dbd-sqlite3
sudo apt-get install -y liblog4cxx-dev
sudo apt-get install -y libjemalloc-dev
sudo apt-get install -y libsqlite3-dev
sudo apt-get install -y libmicrohttpd-dev
sudo apt-get install -y libmuparser-dev
sudo apt-get install -y cmake
sudo apt-get install -y wget curl
