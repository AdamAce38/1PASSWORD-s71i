## some internal utility functions

qw <- function (x) unlist(strsplit(x, "\\s+", perl=TRUE))
