## package initialization

.onLoad <- function (libname, pkgname)
{
	## this used to switch to "quartz" as default plotting device in the R.app GUI on Mac OS X,
	## which is now used by default whenever available (and selected directly in zipfR_par.R)
}
