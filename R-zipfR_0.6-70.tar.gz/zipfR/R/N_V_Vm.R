N <- function (obj, ...)  UseMethod("N")

V <- function (obj, ...)  UseMethod("V")

Vm <- function (obj, m, ...)  UseMethod("Vm")
