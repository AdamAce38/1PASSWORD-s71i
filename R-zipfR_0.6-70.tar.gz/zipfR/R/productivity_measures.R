productivity.measures <- function (obj, measures, data.frame=TRUE, ...) UseMethod("productivity.measures")
