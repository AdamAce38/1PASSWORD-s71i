productivity.measures.tfl <- function (obj, measures, data.frame=TRUE, ...) {
  productivity.measures(tfl2spc(obj), measures, data.frame=data.frame, ...)
}
