VV <- function (obj, N=NA, ...)  UseMethod("VV")

VVm <- function (obj, m, N=NA, ...)  UseMethod("VVm")
