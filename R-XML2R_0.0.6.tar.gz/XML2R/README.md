XML2R
=======

EasieR XML data collection. For an introduction to the package, see [here](http://cpsievert.github.io/XML2R/)

To install the [CRAN](http://cran.r-project.org/web/packages/XML2R/index.html) version use: `install.packages("XML2R"); library(XML2R)`

To install the github version use: `library(devtools); install_github("XML2R", "cpsievert"); library(XML2R)`

TO DO:

(1) Fix naming of observations when no children exist   
(2) Add some tests using testthat   