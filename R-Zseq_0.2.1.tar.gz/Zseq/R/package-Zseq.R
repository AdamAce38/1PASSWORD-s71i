#' Zseq : Integer Sequence Generator
#'
#' The world of integer sequence has long history, which has been accumulated in The On-Line Encyclopedia of Integer Sequences.
#' Even though \code{R} is not a first pick for many number theorists, we introduce our package to enrich the \code{R} ecosystem as well as
#' provide pedagogical toolset. We adopted \pkg{gmp} for flexible large number computations in that users can easily experience
#' large number sequences on a non-exclusive generic computing platform.
#'
#' @docType package
#' @name Zseq-package
#' @import gmp
#' @importFrom utils packageVersion getFromNamespace
NULL
