# Zseq 0.2.1

* Added a `NEWS.md` file to track changes to the package.
* Change of maintainer's contact.
* Reflected comments from Roger Stern (University of Reading).
