# Qindex 0.1.5
Add function nlFRindex().
# Qindex 0.1.2
Bug fix.
# Qindex 0.1.1
Bug fix.
# Qindex 0.1.0
First release.
