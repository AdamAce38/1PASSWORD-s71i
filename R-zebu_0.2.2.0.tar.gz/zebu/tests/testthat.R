library(testthat)
library(zebu)

test_check("zebu")
