##defunct functions - package AICcmodavg M. J. Mazerolle (updated 17 November 2016)
