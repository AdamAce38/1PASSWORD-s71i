library(testthat)
library(AIPW)

test_check("AIPW")
