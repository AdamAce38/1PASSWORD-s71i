KramersKronig
=============

Kramers Kronig transform code: takes a file (usually from maxent or pade) and evaluates the Kramers Kronig transform. See `kk --help` for more options.

Format input data as
````
x1 y1  
x2 y2
... 
````
