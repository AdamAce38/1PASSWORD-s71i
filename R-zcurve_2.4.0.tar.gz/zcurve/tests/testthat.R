library(testthat)
library(vdiffr)
library(zcurve)

test_check("zcurve")
