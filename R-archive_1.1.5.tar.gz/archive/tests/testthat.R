library(testthat)
library(archive)

test_check("archive")
